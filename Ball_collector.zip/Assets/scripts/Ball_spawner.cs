using UnityEngine;

public class Ball_spawner : MonoBehaviour
{
    public GameObject blueBallPrefab;
    public GameObject redBallPrefab;
    public float spawnRate = 2f;
    public float spawnWidth = 8f;

    void Start()
    {
        InvokeRepeating("SpawnBall", 1f, spawnRate);
    }

    void SpawnBall()
    {
        Vector2 spawnPos = new Vector2(Random.Range(-spawnWidth, spawnWidth), transform.position.y);

        // NEW: 70% blue, 30% red probability
        float randomValue = Random.Range(0f, 1f);
        GameObject ballPrefab = (randomValue <= 0.7f) ? blueBallPrefab : redBallPrefab;

        Instantiate(ballPrefab, spawnPos, Quaternion.identity);
    }
}