using UnityEngine;

public class Player_movement : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 8f;
    [SerializeField] private float xBoundary = 8f; // Screen edges

    void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        transform.Translate(Vector2.right * horizontalInput * moveSpeed * Time.deltaTime);

        // Clamp position to screen boundaries
        float clampedX = Mathf.Clamp(transform.position.x, -xBoundary, xBoundary);
        transform.position = new Vector2(clampedX, transform.position.y);
    }
}