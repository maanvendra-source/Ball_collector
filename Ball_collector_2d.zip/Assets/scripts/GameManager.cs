using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI timeText;
    private int score = 0;
    private float timeLeft = 60f;
    private bool isGameActive = true;
    private int blueBallCounter = 0;

    void Update()
    {
        if (isGameActive)
        {
            timeLeft -= Time.deltaTime;
            timeText.text = $"Time: {Mathf.FloorToInt(timeLeft)}s";

            if (timeLeft <= 0)
            {
                isGameActive = false;
                Time.timeScale = 0; // Freeze the game
                Debug.Log("Game Over!");
            }
        }
    }

    public void AddScore(int points)
    {
        score += points;
        scoreText.text = $"Score: {score}";
    }

    public void ReduceTime(int seconds)
    {
        timeLeft = Mathf.Max(0, timeLeft - seconds); // Prevent negative time
    }
    public void CountBlueBall()
    {
        blueBallCounter++;

        if (blueBallCounter % 10 == 0) // Every 10 blue balls
        {
            timeLeft += 10f; // Add 10 seconds
            Debug.Log("10 Blue Balls Bonus! +10 seconds");
        }
    }
}