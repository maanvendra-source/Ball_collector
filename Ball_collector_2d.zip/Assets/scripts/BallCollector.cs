using UnityEngine;

public class BallCollector : MonoBehaviour
{
    public GameManager gameManager;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("BlueBall"))
        {
            gameManager.AddScore(1);
            gameManager.CountBlueBall();
            Destroy(other.gameObject);
        }
        else if (other.CompareTag("RedBall"))
        {
            gameManager.ReduceTime(2);
            gameManager.AddScore(-1);
            Destroy(other.gameObject);
        }
    }
    
}